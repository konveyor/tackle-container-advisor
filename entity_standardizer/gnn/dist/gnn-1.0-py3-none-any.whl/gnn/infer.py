import os
import sys
import torch
import time
import json
import numpy as np
import networkx as nx
import configparser
import logging
from   collections import defaultdict
from   .loader import loader
from   .loader import build_graphs
from   .train  import run_test
from   .data import Dataset
from   .model import Model
from   sklearn.metrics.pairwise import cosine_similarity

def get_code_vector(params, nodes, edges, vocab, model):
    if params['train']['disable_cuda']=='False' and torch.cuda.is_available():
        device    = torch.device('cuda')    
    else:
        device    = torch.device('cpu')
    
    vnodes = torch.as_tensor([vocab.get(t, 0) for t in nodes], dtype=torch.int32)
    vedges  = torch.from_numpy(edges)
    indices= torch.zeros(len(nodes), dtype=torch.long)
    inputs = (vnodes, vedges, indices)
    
    model.eval()
    inputs = [x.to(device=device) for x in inputs]
    with torch.no_grad():
        v = model(*inputs)
        
    cv = v.detach().cpu()
    
    return cv

def predict(config, json_data):
    if config['train']['disable_cuda']=='False' and torch.cuda.is_available():
        device    = torch.device('cuda')    
    else:
        device    = torch.device('cpu')
    logging.info(f"Device = {device}")
    
    start    = time.time()
    graphs   = defaultdict(dict)
    vocab    = defaultdict(str)
    loader(config, graphs, vocab)
    end      = time.time()
    logging.info(f"Data loaded in {end-start:.2f} seconds.")

    data       = Dataset(config, graphs)
    model_dir  = os.path.join(config['general']['model_dir'], config['task']['name'])
    fold       = config['infer']['fold']
    model_name = 'gnn_fold'+fold+'.pt'
    model_path = os.path.join(model_dir, model_name)
    model  = Model(config)
    if not os.path.exists(model_path):
        print(model_name, "does not exist, running training to generate model.")
        from   .train  import train
        model  = train(config, data, graphs)
    else:
        logging.info(f"Loading training parameters from {model_path}.")
        model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device=device)

    (code_vecs, lbls, pids) = run_test(config, model, data, False)

    inf_data      = []
    inf_vecs      = []
    matches       = 0
    predictions   = 0
    for (idx, data) in json_data["data"].items():
        mention   = data.get("mention", "").strip()
        tca_id    = data.get("tca_id", None)
        wd_qid    = data.get("wd_qid", None)
                
        graphs    = build_graphs((config, None, [mention]))
        for i,(problem, vtype, nodes, edges) in enumerate(graphs):
            inf_data.append((idx, tca_id, wd_qid, mention))
            code_vec    = get_code_vector(config, nodes, edges, vocab, model)
            inf_vecs.append(code_vec)

    inf_vecs = torch.cat(inf_vecs, dim=0)
    sim      = torch.from_numpy(cosine_similarity(inf_vecs, code_vecs))
    max_sim_idx = torch.argsort(sim, dim=1, descending=True)

    # Gather top-5 predictions with same inference id
    # and create a dictionary that maps each prediction
    # to a list of similarity scores
    data = json_data["data"]    
    for idx in range(max_sim_idx.shape[0]):
        preds  = list(max_sim_idx[idx, :5])
        inf_id = inf_data[idx][0]
        data[inf_id]["predictions"] = data[inf_id].get("predictions", {})
        for pred in preds:
            data[inf_id]["predictions"][pids[pred]] = data[inf_id]["predictions"].get(pids[pred], []) + [sim[idx, pred]]
    # Sort the predictions in descending order of
    # sum of all similarity scores            
    for inf_id in data:
        predictions = data[inf_id]["predictions"]
        sorted_preds= dict(sorted(predictions.items(), key=lambda item: sum(item[1]), reverse=True))
        pred_tuples = []
        for pred, scores in sorted_preds.items():
            pred_tuples.append((pred, float(sum(scores))))
        data[inf_id]["predictions"] = pred_tuples


'''
if __name__ == "__main__":
    config = configparser.ConfigParser()
    config.read(sys.argv[1]+'.ini')
    if config['graphs']['num_workers'] == '0':
        config['graphs']['num_workers'] = str(os.cpu_count())
    logging.info(f"Num workers = {config['graphs']['num_workers']}")
    
    data_dir = config['general']['data_dir']
    name     = config['task']['name']

    json_file_name = os.path.join(data_dir, name, 'infer.json')
    with open(json_file_name, 'r', encoding='utf-8') as graphs_file:
        json_data = json.load(graphs_file)

    infer_data = predict(config, json_data)
'''
