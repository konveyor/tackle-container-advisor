import os
import sys
import time
import torch
import json
import pickle
import tqdm
import configparser
import numpy as np
import statistics as st
import networkx as nx
import torch.optim as optim
import torch.nn as nn

from   collections import defaultdict
from   networkx.readwrite import json_graph
from   sklearn.metrics.pairwise import cosine_similarity
from   sklearn.metrics import silhouette_score
from   .loader import loader
from   .data import Dataset
from   .model import Model
from   .model import CircleLoss
    
    
def map_at_r(sim, pids):
    r = torch.bincount(pids) - 1
    max_r = r.max()

    mask = torch.arange(max_r)[None, :] < r[pids][:, None]

    sim = sim.clone()
    ind = np.diag_indices(len(sim))
    sim[ind[0], ind[1]] = -np.inf

    _, result = torch.topk(sim, max_r, dim=1, sorted=True)

    tp = (pids[result] == pids[:, None])
    tp[~mask] = False

    valid = r[pids] > 0

    p = torch.cumsum(tp, dim=1).float() / torch.arange(1, max_r+1)[None, :]
    ap = (p * tp).sum(dim=1)[valid] / r[pids][valid]

    return ap.mean().item()

    
def pairwise_cosine_similarity(h):
    h_norm = torch.nn.functional.normalize(h, dim=1)
    sim = torch.mm(h_norm, h_norm.transpose(0, 1))
    return sim


def compute_pairwise_scores(h, pids):
    sim = pairwise_cosine_similarity(h)
    inds = torch.triu_indices(len(pids), len(pids), offset=1)
    sim = sim[inds[0], inds[1]]
    positive = pids[inds[0]] == pids[inds[1]]
    s_p = sim[positive]
    s_n = sim[~positive]
    return s_p, s_n

def iterations(params, model, criterion, optimizer, epoch, data, training):
    if params['train']['disable_cuda']=='False' and torch.cuda.is_available():
        device    = torch.device('cuda')    
    else:
        device    = torch.device('cpu')    
    num_iters = int(params['train']['train_epoch_size'])
        
    model.train(training)

    total_loss = 0

    for itr in range(num_iters):
        inputs, pids = data.get_train_sample_generator(int(params['sample']['p']), int(params['sample']['k']))
        inputs = [x.to(device=device) for x in inputs]
        code_vecs = model(*inputs)
        # print("Code vecs total = ", torch.sum(code_vecs))
        # print("Iteration", itr, "code_vecs = ", code_vecs)
        s_p, s_n = compute_pairwise_scores(code_vecs, pids.to(device=device))
        # print("Iteration", itr, "s_p = ", s_p)
        loss = criterion(s_p, s_n)
        # print("Iteration", itr, "loss = ", loss)
        total_loss += loss.item()
        if training:
            model.zero_grad()
            loss.backward()
            optimizer.step()
        
    avg_loss = total_loss / num_iters

    return avg_loss


def train(params, data, graphs):
    np.random.seed(int(params['train']['seed']))
    torch.manual_seed(int(params['train']['seed']))
    if params['train']['disable_cuda']=='False' and torch.cuda.is_available():
        device    = torch.device('cuda')    
    else:
        device    = torch.device('cpu')    
    n_folds       = params['train']['n_folds']
    labels        = sorted(graphs.keys())
    models        = []
    scores        = []
    epochs        = []
    for i, (train, test) in enumerate(data.skf.split(labels)):
        train         = list(train)
        test          = list(test)
        data.train.clear()
        for idx in train:
            data.train[labels[idx]]    = data.graphs[labels[idx]]
        data.test.clear()
        for idx in test:
            data.test[labels[idx]]    = data.graphs[labels[idx]]
        model      = Model(params)
        model.to(device=device)
        model_dir  = os.path.join(params['general']['model_dir'], params['task']['name'])
        model_name = 'gnn_fold'+str(i)+'.pt'
        model_path = os.path.join(model_dir, model_name)
        criterion = CircleLoss(gamma=float(params['loss']['gamma']), m=float(params['loss']['margin']))
        criterion.to(device)
        optimizer = optim.AdamW(model.parameters(), lr=float(params['train']['lr']))
        
        best_val         = None
        best_epoch       = 0
        with tqdm.tqdm(range(1, int(params['train']['epoch_num'])+1, 1), ncols=100, desc='Fold '+str(i+1)+'/'+n_folds) as progress:
            for epoch in progress:
                iterations(params, model, criterion, optimizer, epoch, data, True)
                # Note - Saving last epoch for words
                # best_epoch = epoch
                best_val, best_epoch = validate(params, model, data, criterion, epoch, best_val, best_epoch)
                if epoch == best_epoch:
                    model_dir  = os.path.join(params['general']['model_dir'], params['task']['name'])
                    os.makedirs(model_dir, exist_ok=True)
                    torch.save(model.state_dict(), model_path)
            print(f"Fold {i+1}/{n_folds}: Best {params['train']['valid_metric']} score = {best_val:.2f}, Best epoch = {best_epoch}")
            
        epochs.append(best_epoch)
        scores.append(best_val)
        models.append(model)

    print("Average val. score = %.2f" % (st.mean(scores)))    
    return models[0]

def validate(params, model, data, criterion, epoch, best_val, best_epoch):
    code_vecs, lbls, pids = run_test(params, model, data)

    if params['train']['valid_metric'] == 'silhouette':
        sil_score = silhouette_score(code_vecs, lbls)
        
        if best_val is None or sil_score > best_val:
            best_val = sil_score
            best_epoch = epoch
        # print(f'* validation Silhouette score: {sil_score}, best epoch: {best_epoch}, best Silhouette score: {best_val}')
        return best_val, best_epoch
    elif params['train']['valid_metric'] == 'map@r':
        sim = pairwise_cosine_similarity(code_vecs)    
        map_r = map_at_r(sim, lbls)
        if best_val is None or map_r > best_val:
            best_val = map_r
            best_epoch = epoch
        # print(f'* validation MAP@R: {map_r}, best epoch: {best_epoch}, best MAP@R: {best_val}')            
        return best_val, best_epoch

def run_test(params, model, data, valid = True):
    if params['train']['disable_cuda']=='False' and torch.cuda.is_available():
        device    = torch.device('cuda')    
    else:
        device    = torch.device('cpu')    
    model.eval()
    batch_size = int(params['train']['batch_size'])
    test_gen_fun, num_iters = data.get_infer_generator(batch_size, valid)

    code_vecs = []
    lbls      = []
    pids      = []
    inf_lst   = []
    for inputs, lbls_batch, pids_batch in test_gen_fun():
        inputs = [x.to(device=device) for x in inputs]
        with torch.no_grad():
            inf_start = time.time()
            v = model(*inputs)
            inf_end = time.time()
            inf_lst += [(inf_end-inf_start)]
        code_vecs.append(v.detach().cpu())
        lbls.append(lbls_batch)
        pids += pids_batch
    code_vecs = torch.cat(code_vecs, dim=0)
    lbls      = torch.cat(lbls)

    return code_vecs, lbls, pids

if __name__ == "__main__":    
    config = configparser.ConfigParser()
    config.read(sys.argv[1]+'.ini')
    if config['graphs']['num_workers'] == '0':
        config['graphs']['num_workers'] = str(os.cpu_count())
    print("Num workers = ", config['graphs']['num_workers'])
    
    start    = time.time()
    graphs   = defaultdict(dict)
    vocab    = defaultdict(str)
    loader(config, graphs, vocab)
    end      = time.time()
    data     = Dataset(config, graphs)
    model    = train(config, data, graphs)
