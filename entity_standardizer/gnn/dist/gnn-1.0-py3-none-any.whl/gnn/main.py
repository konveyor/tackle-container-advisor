import os
import json
import logging

class GNN():
    def __init__(self, task_name):
        super().__init__()
        import configparser

        log  = logging.getLogger()
        for hdlr in log.handlers[:]:  # remove all old handlers
            hdlr.close()
            log.removeHandler(hdlr)
        logging.basicConfig(filename='gnn.log',level=logging.DEBUG, \
                            format="[%(levelname)s:%(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s", filemode='w')
        
        self.task_name = task_name
        self.config    = configparser.ConfigParser()
        common         = os.path.join("config", "common.ini")
        gnn            = os.path.join("config", self.task_name, "gnn.ini")
        self.config.read([common, gnn])
        self.config["task"] = {}
        self.config["task"]["name"] = self.task_name
        
        if self.config['graphs']['num_workers'] == '0':
            self.config['graphs']['num_workers'] = str(os.cpu_count())
        logging.info(f"Num workers = {self.config['graphs']['num_workers']}")
                   
    def infer(self, infer_data):
        from .infer import predict
        predict(self.config, infer_data)
        return infer_data

