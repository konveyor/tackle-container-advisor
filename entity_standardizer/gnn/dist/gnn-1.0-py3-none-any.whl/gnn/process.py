import os
import re
import networkx as nx

def bfs_node(DG, node):
    bfs_list = []
    nxt_list = [node]        
    while nxt_list:
        node = nxt_list[0]
        bfs_list.append(node)
        nxt_list.pop(0)
        children = list(DG.successors(node))
        nxt_list += children

    return bfs_list


def bfs(DG):
    bfs_list = []
    nxt_list = [n for n,d in DG.in_degree() if d==0]        
    while nxt_list:
        node = nxt_list[0]
        bfs_list.append(node)
        nxt_list.pop(0)
        children = list(DG.successors(node))
        nxt_list += children

    return bfs_list

def dfs_rec(DG, node, dfs_list):
    children = list(DG.successors(node))
    for child in children:
        dfs_rec(DG, child, dfs_list)
    dfs_list.append(node)

def dfs(DG):
    dfs_list = []
    nxt_list = [n for n,d in DG.in_degree() if d==0]        
    while nxt_list:
        node = nxt_list[0]
        dfs_rec(DG, node, dfs_list)
        nxt_list.pop(0)
        
    return dfs_list

def remove_redundant_tokens(DG):
    nodes_to_remove = []
    for n in DG.nodes:
        node = DG.nodes[n]
        node_type      = node['node-type']
        type_rule_name = node['type-rule-name']            
        label          = node['label']
        if node_type == "Token" and not (type_rule_name    == "Identifier" 
                                         or type_rule_name == "Literal"
                                         or type_rule_name == "Constant"
                                         or type_rule_name == "IntegerLiteral" #Added
                                         or type_rule_name == "StringLiteral"
                                         or type_rule_name == "IDENTIFIER"
                                         or type_rule_name == "DECIMAL_LITERAL"
                                         or type_rule_name == "FLOAT_LITERAL"                                         
                                         or type_rule_name == "CHAR_LITERAL"
                                         or type_rule_name == "STRING_LITERAL"
                                         or type_rule_name == "BOOL_LITERAL"
                                         or type_rule_name == "NAME"
                                         or type_rule_name == "DECIMAL_INTEGER"
                                         or type_rule_name == "FLOAT_NUMBER"
                                         or type_rule_name == "STRING"):
            nodes_to_remove.append(n)
    DG.remove_nodes_from(nodes_to_remove)
    return DG

def merge_nodes(DG, parent, node):
    parent_children = list(DG.successors(parent))
    parent_label    = DG.nodes[parent]['label']
    positions       = [m.start() for m in re.finditer('#', parent_label)]
    node_children   = list(DG.successors(node))
    node_label      = DG.nodes[node]['label']
    node_idx        = parent_children.index(node)
    
    ins_pos        = positions[node_idx]
    parent_label   = parent_label[0:ins_pos] + node_label + parent_label[ins_pos+1:]
    DG.nodes[parent]['label'] = parent_label
    
    remove_edges = []
    add_edges    = []
    for child in parent_children:
        remove_edges.append((parent, child))
        
    for child in node_children:
        remove_edges.append((node, child)) 

    parent_children[node_idx:node_idx+1] = node_children
    for child in parent_children:
        add_edges.append((parent, child))
        
    DG.remove_edges_from(remove_edges)
    DG.add_edges_from(add_edges)
                        
    
def flatten_tree(DG):
    remove_nodes = []
    for node in dfs(DG):
        ndict          = DG.nodes[node]
        node_type      = ndict['node-type']
        type_rule_name = ndict['type-rule-name']            
        children       = list(DG.successors(node))
        num_child      = len(children)
        
        if node_type == "Rule" and (type_rule_name    == "blockItemList"
                                    or type_rule_name == "block"
                                    or type_rule_name == "statement"
                                    or type_rule_name == "blockStatement"
                                    or type_rule_name == "small_stmt"
                                    or type_rule_name == "simple_stmt"
                                    or type_rule_name == "initDeclarator"      #Added
                                    or type_rule_name == "declSpecifierSeq"    #Added
                                    or type_rule_name == "braceOrEqualInitializer"    #Added
        ):  
            remove_nodes.append(node)
            parent          = list(DG.predecessors(node))[0]
            merge_nodes(DG, parent, node)
        
    DG.remove_nodes_from(remove_nodes)

    return DG

def get_roots(DG):
    roots = []
    for node in DG:
        parent = list(DG.predecessors(node))
        if not parent:
            roots.append(node)

    return roots

def delete_tree(DG):
    roots = get_roots(DG)

    nodes_to_remove = []
    for root in roots:
        rdict          = DG.nodes[root]
        root_type      = rdict['node-type']
        root_rule_name = rdict['type-rule-name']            

        if root_type == "Rule" and root_rule_name == "translationUnit":
            nodes_to_remove += bfs_node(DG, root)

    DG.remove_nodes_from(nodes_to_remove)

    return DG
            
def split_tree(DG):
    edges_to_remove = []
    for node in dfs(DG):
        ndict          = DG.nodes[node]
        node_type      = ndict['node-type']
        type_rule_name = ndict['type-rule-name']            

        parent = list(DG.predecessors(node))
        if not parent:
            continue
        parent_type = DG.nodes[parent[0]]['node-type']
        parent_rule_name = DG.nodes[parent[0]]['type-rule-name']
        if type_rule_name == "compoundStatement" and parent_type == "Rule" and \
           (parent_rule_name == "functionDefinition" or parent_rule_name == "functionTryBlock"):
            edges_to_remove.append((parent[0], node))

            
    DG.remove_edges_from(edges_to_remove)

    return DG
        
def process_graph(DG):
    DG = remove_redundant_tokens(DG)
    DG = flatten_tree(DG)
    DG = split_tree(DG)
    DG = delete_tree(DG)
    
    tokens = ["S#FS#1_0"]
    tokcnt = 1
    idx    = 1        
    for n in bfs(DG):
        node = DG.nodes[n]
        node_type      = node['node-type']
        type_rule_name = node['type-rule-name']            
        label          = node['label']
        
        label= label.replace('\t','\\t') # Some C++ files have tabs in print statements
        label= label.replace('\n','\\n')  # Some C++ files have newlines in print statements
        children = list(DG.successors(n))
        num_child= len(children)
        node_label   = label
        
        if node_type == "Rule":
            if num_child == 0:
                tokcnt += 1
                node_label = "S"+label
                node['label'] = node_label
                tokens.append(node_label)
            else:
                tokcnt += 1
                node_label = "I#compund_statement#"+label
                node['label'] = node_label
                tokens.append(node_label)
                tokens.append(str(num_child))
        elif node_type == "Token":
            if type_rule_name == "Identifier" or type_rule_name == "IDENTIFIER" or type_rule_name == "NAME":
                tokcnt += 1
                node_label = "V"+label
                node['label'] = node_label
                tokens.append(node_label)      # Local variable, local function, global variable, global function
            elif type_rule_name == "Literal": # Includes numbers, chars
                tokcnt += 1
                node_label = "C"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "Constant": # Includes numbers
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            #Added
            elif type_rule_name == "IntegerLiteral": # Includes integers
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            #Added
            elif type_rule_name == "StringLiteral": # Includes strings
                tokcnt += 1
                node_label = "S"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "DECIMAL_LITERAL": # Includes numbers (Java)
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "FLOAT_LITERAL": # Includes numbers (Java)
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "CHAR_LITERAL": # Includes characters (Java)
                tokcnt += 1                    
                node_label = "C"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "STRING_LITERAL": # Includes strings (Java)
                tokcnt += 1
                node_label = "S"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "BOOL_LITERAL": # Includes bool (Java)
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "DECIMAL_INTEGER": # Includes numbers (Python)
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "FLOAT_NUMBER": # Includes numbers (Python)
                tokcnt += 1
                node_label = "N"+label
                node['label'] = node_label
                tokens.append(node_label)
            elif type_rule_name == "STRING": # Includes strings (Python)
                tokcnt += 1
                node_label = "S"+label
                node['label'] = node_label
                tokens.append(node_label)                    
    return DG
    
def add_hops(params, graph):
    max_hops  = int(params['graphs']['max_hops'])
    new_edges = []
    for node in graph.nodes:
        gen = [[node]]
        for h in range(max_hops):
            successors = []
            for child in gen[h]:
                next_level = list(graph.successors(child))
                successors += next_level
            gen.append(successors)

        for h in range(2,max_hops+1,1):
            for child in gen[h]:
                new_edges.append((node, child))

    graph.add_edges_from(new_edges)

