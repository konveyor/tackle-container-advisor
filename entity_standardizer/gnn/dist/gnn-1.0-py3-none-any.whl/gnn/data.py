import torch
import torch.nn as nn
import numpy as np
from sklearn.model_selection import KFold
from numpy.random import default_rng

class Dataset():    
    def __init__(self, params, graphs):
        self.graphs = graphs
        self.seed   = int(params['train']['seed'])
        self.skf    = KFold(n_splits=int(params['train']['n_folds']), shuffle=True, random_state=self.seed)
        self.train  = {}
        self.test   = {}


    def get_train_sample_generator(self, p, k):
        problems = sorted(self.train.keys())
        pids = np.random.choice(len(problems), p, replace=False)
        batch = []
        labels = []
        for pid in pids:
            solutions = sorted(self.train[problems[pid]].keys())
            solution_num = len(solutions)
            # Note : replace = True for words
            # p_sample_num = solution_num if solution_num < k else k
            p_sample_num = k
            replace = True if solution_num < p_sample_num else False
            sids = np.random.choice(solutions, p_sample_num, replace=replace)
            for sid in sids:
                batch.append((self.train[problems[pid]][sid]['nodes'], self.train[problems[pid]][sid]['edges']))
                labels.append(pid)
        node_counts = [len(b[0]) for b in batch]
        return self.assemble(batch), torch.tensor(labels)
            
    def get_infer_generator(self, batch_size, valid = True):
        if valid:
            pids       = list(self.test.keys())
        else:
            pids       = list(self.graphs.keys())
            
        sids       = []
        for i, pid in enumerate(pids):
            if valid:
                sids += [(i, pid, sid) for sid in list(self.test[pid].keys())]
            else:
                sids += [(i, pid, sid) for sid in list(self.graphs[pid].keys())]

        num_batches = len(sids) // batch_size
        if len(sids) % batch_size > 0:
            num_batches += 1

        def gen():
            labels= []
            batch = []
            pids  = []
            for lid, pid, sid in sids:
                if valid:
                    batch.append((self.test[pid][sid]['nodes'], self.test[pid][sid]['edges']))
                else:
                    batch.append((self.graphs[pid][sid]['nodes'], self.graphs[pid][sid]['edges']))
                labels.append(lid)
                pids.append(pid)
                if len(batch) == batch_size:
                    yield self.assemble(batch), torch.tensor(labels), pids
                    labels= []
                    batch = []
                    pids  = []
                    
            if len(batch) > 0:
                yield self.assemble(batch), torch.tensor(labels), pids

        return gen, num_batches
    
    def assemble(self, batch):       
        num_prev_nodes = 0
        nodes_batch = []
        edges_batch = []
        indices = []
        for i, (nodes, edges) in enumerate(batch):
            num_nodes = nodes.shape[0]
            nodes_batch.append(torch.from_numpy(nodes))
            edges_batch.append(torch.from_numpy(edges) + num_prev_nodes)
            num_prev_nodes += num_nodes
            indices.append(torch.full((num_nodes,), i, dtype=torch.long))

        return torch.cat(nodes_batch), torch.cat(edges_batch, dim=1), torch.cat(indices) 
