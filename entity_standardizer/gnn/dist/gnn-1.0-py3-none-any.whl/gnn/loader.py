import os
import re
import sys
import json
import pickle
import time
import numpy as np
import networkx as nx
import multiprocessing
import logging
from   collections import defaultdict
from   networkx.readwrite import json_graph
from   .process import process_graph
from   .process import add_hops
    
def load_graphs(arguments):
    params, problem, solutions = arguments
    data_dir    = params['general']['data_dir']
    name        = params['task']['name']
    problem_dir = os.path.join(data_dir, name, problem)

    graphs_list = []
    for solution in solutions:
        graph_path  = os.path.join(problem_dir, solution+'.json')

        with open(graph_path, 'r', encoding='utf-8') as jgraph:
            data = json.load(jgraph)
            DG   = json_graph.adjacency_graph(data)
            add_hops(params, DG)
            
        if len(DG.nodes) == 0:
            print("(E)", graph_path, "has no nodes") 
            continue
        
        assert len(DG.nodes) > 0
        nodes = [DG.nodes[n]['label'] for n in DG.nodes]    
        edges = np.asarray(list(DG.edges()), dtype=np.int).T 

        graphs_list.append((problem, solution, nodes, edges))
        
    return graphs_list

def process_graphs(arguments):
    params, problem, solutions = arguments
    data_dir    = params['general']['data_dir']
    name        = params['task']['name']
    problem_dir = os.path.join(data_dir, name, problem)

    graphs_list = []
    for solution in solutions:
        graph_path  = os.path.join(problem_dir, solution+'.json')

        DG = nx.DiGraph()
        with open(graph_path, 'r', encoding='utf-8') as jgraph:
            G  = json.load(jgraph)
            for node in G['graph']['nodes']:
                node_id = node['id']
                DG.add_node(node_id)
                for key in node.keys():
                    DG.nodes[node_id][key] = node[key]

            for edge in G['graph']['edges']:
                edge_from = edge['between'][0]
                edge_to   = edge['between'][1]
                DG.add_edge(edge_from, edge_to)
                
            process_graph(DG)
            mapping      = dict(zip(DG, range(len(DG.nodes))))
            DG           = nx.relabel_nodes(DG, mapping)
            add_hops(params, DG)
            
        if len(DG.nodes) == 0:
            print("(E)", graph_path, "has no nodes") 
            continue
        
        assert len(DG.nodes) > 0
        nodes = [DG.nodes[n]['label'] for n in DG.nodes]    
        edges = np.asarray(list(DG.edges()), dtype=np.int).T 
        
        graphs_list.append((problem, solution, nodes, edges))
        
    return graphs_list

    
def build_graphs(arguments):
    params, qid, mentions = arguments
    graphs_list = []
    variations  = {}
    for i, mention in enumerate(mentions):
        variations[mention] = str(i)+'_exact'
        lower = mention.lower()
        if lower not in variations:
            variations[lower] = str(i)+'_lower'
        title = mention.title()
        if title not in variations:            
            variations[title] = str(i)+'_title'
        
    for var, vtype in variations.items():
        DG = nx.DiGraph()
        if qid is not None:
            DG.graph = {'id':qid, 'word':var, 'word_type':vtype}
        else:
            DG.graph = {'id':'None', 'word':var, 'word_type':vtype}
        words = var.split(" ")
        idx   = 0
        for word in words:            
            DG.add_nodes_from(range(idx+len(word)))
            for n in range(idx,idx+len(word),1):
                DG.nodes[n]['label'] = word[n-idx]
                if n+1 < idx+len(word):
                    DG.add_edge(n,n+1)
            idx += len(word)

        add_hops(params, DG)
        nodes = [DG.nodes[n]['label'] for n in DG.nodes]    
        edges = np.asarray(list(DG.edges()), dtype=np.int).T 

        graphs_list.append((qid, vtype, nodes, edges))
        
    return graphs_list
                
    
def compute_graph_maps(params, graphs, vocab):
    for problem in graphs:
        for solution in graphs[problem]:
            graphs[problem][solution]['nodes'] = np.asarray([vocab.get(label, 0) for label in graphs[problem][solution]['nodes']])
            
            
def compute_vocab(params, counts, vocab):
    min_freq  = int(params['vocab']['min_freq'])
    vocab[''] = 0 # Reserve 0 for UNK
    vocab_count_list = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)
    total            = sum(map(lambda wc: wc[1], vocab_count_list))
    in_vocab         = 0
    for i, (word, freq) in enumerate(vocab_count_list):
        if freq < min_freq:
            break
        vocab[word] = len(vocab)
        in_vocab  += freq

    params['vocab']['size'] = str(len(vocab))
    logging.info(f'Vocab size: {len(vocab)}/{len(vocab_count_list)+1}')
    logging.info(f'Vocab coverage: {in_vocab}/{total} = {in_vocab/total:.2%}')


def loader(params, graphs, vocab):
    load_start  = time.time()
    data_dir    = params['general']['data_dir']
    name        = params['task']['name']
    num_workers = int(params['graphs']['num_workers'])
    counts      = defaultdict(int)    
        
    json_file_name = os.path.join(data_dir, name, 'train.json')
    with open(json_file_name, 'r', encoding='utf-8') as graphs_file:
        json_data = json.load(graphs_file)

    paths     = []
    data      = json_data["data"]
    function  = None
    if json_data["data_type"] == "strings":
        for idx, item in data.items():
            paths.append((params, item["label"], item["mentions"]))
        function = build_graphs
    elif json_data["data_type"] == "spts":
        for problem, solutions in data.items():
            for solution in solutions:
                paths.append((params, problem, [solution]))    
        function = process_graphs
    elif json_data["data_type"] == "graphs":
        for problem, solutions in data.items():
            for solution in solutions:
                paths.append((params, problem, [solution]))    
        function = load_graphs
        
    num_none  = 0
    num_sols  = 0
    with multiprocessing.Pool(num_workers) as pool:
        for graphs_list in pool.imap_unordered(function, paths, chunksize=10):
            for (problem, solution, nodes, edges) in graphs_list:
                graphs[problem][solution] = {}
                if nodes is None or len(nodes) == 0:
                    num_none += 1                    
                else:
                    num_sols += 1
                    graphs[problem][solution]['nodes'] = nodes
                    graphs[problem][solution]['edges'] = edges

    if num_none > 0:
        print(num_none, "graphs were empty")

    load_end   = time.time()
    logging.info(f"Loading {len(graphs)} graph classes, {num_sols} solutions took {load_end-load_start:.2f} seconds.") 
    vocab_start= time.time()
    for problem in graphs:
        for solution in graphs[problem]:
            for label in graphs[problem][solution]['nodes']:
                counts[label] += 1
    compute_vocab(params, counts, vocab)
    vocab_end  = time.time()
    logging.info(f"Vocabulary computation took {vocab_end-vocab_start:.2f} seconds.")        
    map_start  = time.time()
    compute_graph_maps(params, graphs, vocab)
    map_end    = time.time()
    logging.info(f"Graph map computation took {map_end-map_start:.2f} seconds.")
