from .main import GNN
