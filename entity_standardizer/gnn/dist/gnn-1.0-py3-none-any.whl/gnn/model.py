import torch
import torch.nn as nn
from   torch_scatter import scatter_max, scatter_mean, scatter_add
import torch.nn.functional as F

class CircleLoss(nn.Module):
    def __init__(self, gamma, m):
        super().__init__()        
        self.gamma = gamma
        self.m = m

    def forward(self, s_p, s_n):
        # print("s_p total = ", torch.sum(s_p))
        # print("s_n total = ", torch.sum(s_n))
        alpha_p = torch.clamp_min(1 + self.m - s_p, 0)
        alpha_n = torch.clamp_min(self.m + s_n, 0)
        delta_p = 1 - self.m
        delta_n = self.m
        logit_p = (-self.gamma) * alpha_p * (s_p - delta_p)
        logit_n = self.gamma * alpha_n * (s_n - delta_n)
        # print("Logit p = ", logit_p, "Logit n = ", logit_n)
        return F.softplus(torch.logsumexp(logit_p, dim=0) + torch.logsumexp(logit_n, dim=0))



class Model(nn.Module):
    def __init__(self, params):
        super().__init__()
        self.seed = int(params['train']['seed'])
        self.num_layers = int(params['model']['num_layers'])
        dropout = float(params['train']['dropout'])
        if dropout > 0:
            self.node_emb = nn.Sequential(
                nn.Embedding(int(params['vocab']['size']), int(params['model']['node_emb_size'])),
                nn.Dropout(dropout)
            )
        else:
            self.node_emb = nn.Sequential(
                nn.Embedding(int(params['vocab']['size']), int(params['model']['node_emb_size']))
            )            
        self.gnn_layers = nn.ModuleList(
            [GraphConv(int(params['model']['node_emb_size'])) for _ in range(int(params['model']['num_layers']))])
        self.out = nn.Sequential(
            nn.Linear(int(params['model']['node_emb_size']) * 2, int(params['model']['output_size']))
        )


    def forward(self, nodes, edges, indices):
        # print("Nodes = ", nodes)
        # print("Edges = ", edges)
        # print("Indices = ", indices)
        torch.manual_seed(self.seed)    
        # torch.use_deterministic_algorithms(True)
        h = self.node_emb(nodes)
        # print("Shape of h = ", h.shape)
        # print(f"H: Shape = {h.shape}, sum = {torch.sum(h)}")
        for i in range(self.num_layers):
            h = self.gnn_layers[i](h, edges)        
        # torch.use_deterministic_algorithms(False)
        v = torch.cat(
            (
                scatter_mean(h, indices, dim=0),
                scatter_max(h, indices, dim=0)[0]
            ),
            dim=1
        )
        
        return self.out(v)


class GraphConv(nn.Module):
    def __init__(self, node_emb_size):
        super().__init__()
        self.W0 = nn.Linear(node_emb_size, node_emb_size, bias=False)
        self.W1 = nn.Linear(node_emb_size, node_emb_size, bias=False)
        self.W2 = nn.Linear(node_emb_size, node_emb_size, bias=False)

    def forward(self, nodes, edges):
        if len(edges) > 0:
            nbr_msg = torch.cat((self.W1(nodes[edges[0]]), self.W2(nodes[edges[1]])), dim=0)
            msg = scatter_mean(nbr_msg, torch.cat((edges[1], edges[0])), dim=0, dim_size=nodes.size(0))
            return torch.relu(self.W0(nodes) + msg)
        else:
            return torch.relu(self.W0(nodes))
