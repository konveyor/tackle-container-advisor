import os
import json
import logging

class TFIDF():
    def __init__(self, task_name):
        super().__init__()
        import configparser

        self.task_name = task_name                           
        self.config    = configparser.ConfigParser()
        common = os.path.join("config", self.task_name, "common.ini")
        tfidf  = os.path.join("config", self.task_name, "tfidf.ini")
        self.config.read([common, tfidf])
        
        fileh     = logging.FileHandler('tfidf.log', 'w')
        formatter = logging.Formatter("[%(levelname)s:%(filename)s:%(lineno)s - %(funcName)20s()] %(message)s")
        fileh.setFormatter(formatter)
        log       = logging.getLogger()  # root logger
        for hdlr in log.handlers[:]:  # remove all old handlers
            log.removeHandler(hdlr)
        log.addHandler(fileh)      # set the new handler
                
    def infer(self, infer_file_name):
        from .infer import predict

        try:
            data_dir = self.config['general']['data_dir']
            name     = self.config['general']['name']
        except KeyError as k:
            logging.error(f'{k} is not a key in your tfidf.ini file.')
            print(f'{k} is not a key in your tfidf.ini file.')
            exit()

        if name != self.task_name:
            print(f"Incorrect config file - config file meant for {name} but is being used for {self.task_name}")
            exit
            
        json_file_name = os.path.join(data_dir, name, infer_file_name)
        with open(json_file_name, 'r', encoding='utf-8') as graphs_file:
            json_data = json.load(graphs_file)
        
        predict(self.config, json_data)        
        return json_data
