import os
import json
import logging

class TFIDF():
    def __init__(self, task_name):
        super().__init__()
        import configparser

        self.task_name = task_name                           
        self.config    = configparser.ConfigParser()
        common = os.path.join("config", "common.ini")
        kg     = os.path.join("config", "kg.ini")
        tfidf  = os.path.join("config", self.task_name, "tfidf.ini")
        self.config.read([common, kg, tfidf])
        self.config["task"] = {}
        self.config["task"]["name"] = self.task_name
                
        fileh     = logging.FileHandler('tfidf.log', 'w')
        formatter = logging.Formatter("[%(levelname)s:%(filename)s:%(lineno)s - %(funcName)20s()] %(message)s")
        fileh.setFormatter(formatter)
        log       = logging.getLogger()  # root logger
        for hdlr in log.handlers[:]:  # remove all old handlers
            hdlr.close()
            log.removeHandler(hdlr)
        log.addHandler(fileh)      # set the new handler
                
    def infer(self, infer_data):
        from .infer import predict
        logging.info("Test")
        predict(self.config, infer_data)        
        log       = logging.getLogger()  # root logger
        for hdlr in log.handlers[:]:  # remove all old handlers
            hdlr.close()
            log.removeHandler(hdlr)
        return infer_data


